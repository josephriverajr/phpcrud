<?php

$servername = "localhost";
$database = "test";
$username = "root";
$password = "";
$connection = new PDO ("mysql:host=localhost;dbname=test","root","");
$con = mysqli_connect($servername, $username, $password, $database);

?>