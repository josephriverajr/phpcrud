<?php
require ("database.php");
$con = mysqli_connect($servername, $username, $password, $database);

$result = ' SELECT *
            FROM test;';
  $statement = $connection->prepare($result);
      $statement->execute();
      $payments = $statement->fetchAll(PDO::FETCH_OBJ);   

   

echo "<table border='1'  class='table table-striped table-bordered table-hover' id='dataTables-example' >
<tr>

<th><b>1</b></td></th>
<th><b>2</b></td></th>
<th><b>3</b></td></th>
<th><b>Actions</b></td></th>
";
   foreach($payments as $package):   

    echo "<tr id=".$package->id_no.">";
    echo "<td >".$package->username."</td>";
    echo "<td >".$package->email_address."</td>";
    echo "<td >".$package->date."</td>";
 	  echo "<td ><a href='pdf.php?id_no=".$package->id_no."'>Generate</a>
      </td>";
  
 endforeach;
 echo "</table>";
?>
<script type="text/javascript">
  
  function myFunction() {  
    var txt;
  var r = confirm("Press a button!");
    if (r == true) {
     /*document.getElementById("sss").href = "https://www.w3schools.com";*/
  } else {
    document.getElementById("sss").href = "#";

  
}}
</script>