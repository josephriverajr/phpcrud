<?php
session_start();

$servername = "localhost";
$database = "test";
$username = "root";
$password = "";
$connection = new PDO ("mysql:host=localhost;dbname=test","root","");
require('fpdf181/fpdf.php');
$pdf = new FPDF('P','mm','A4');

$con = mysqli_connect($servername, $username, $password, $database);
$id_no = $_GET['id_no'];

 
  /* echo "SELECT * FROM test WHERE id_no = ".$id_no;*/
       $stmt = $connection->query("SELECT * FROM test WHERE id_no = ".$id_no);

      $pdf->AddPage();
      $pdf->SetFont('Arial','',12);
    while ($package = $stmt->fetch(PDO::FETCH_OBJ)) 
    {



      $pdf->Cell(10,10,' '.$package->username,'B',0,'L');
      $pdf->Cell(15,10,' '.$package->email_address,'B',0,'L');
      $pdf->Cell(20,10,' '.$package->date,'B',0,'L');
      }
      $pdf->Output();




?>
